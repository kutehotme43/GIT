﻿namespace Guna
{
    internal class UI2
    {
    }
}