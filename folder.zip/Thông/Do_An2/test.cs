﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Do_An2
{
    public partial class test : Form
    {
        public test()
        {
            InitializeComponent();
            Test();
        }
        public void Test()
        {
            byte[] temp = ASCIIEncoding.ASCII.GetBytes("Admin");
            byte[] hasData = new MD5CryptoServiceProvider().ComputeHash(temp);
            string haspass = "";
            foreach (byte i in hasData)
            {
                haspass += i;
            }
            textBox1.Text = haspass;
        }
    }
}
