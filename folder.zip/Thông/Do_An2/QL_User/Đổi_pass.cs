﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Do_An2
{
    public partial class Đổi_pass : Form
    {
        int id_TaiKhoan;
        public Đổi_pass(int id_taikhoan)
        {
            id_TaiKhoan = id_taikhoan;
            InitializeComponent();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox2.Text == textBox3.Text)
            {
                byte[] temp = ASCIIEncoding.ASCII.GetBytes(textBox1.Text);
                byte[] hasData = new MD5CryptoServiceProvider().ComputeHash(temp);
                String haspass = "";
                foreach (byte i in hasData)
                {
                    haspass += i;
                }
                byte[] temp2 = ASCIIEncoding.ASCII.GetBytes(textBox2.Text);
                byte[] hasData2 = new MD5CryptoServiceProvider().ComputeHash(temp2);
                String haspass2 = "";
                foreach (byte j in hasData2)
                {
                    haspass2 += j;
                }
                Model1 db = new Model1();
                foreach (TaiKhoan i in db.TaiKhoan)
                {
                    if (i.idTaiKhoan == id_TaiKhoan)
                    {
                        if (i.pass.ToString() == haspass.ToString())
                        {
                            
                            i.pass = haspass2.ToString();                            
                            MessageBox.Show("Thành Công");
                            this.Dispose();
                            this.Close();
                        }
                        else
                        {
                            MessageBox.Show("sai mật khẩu");
                        }
                    }
                }
                db.SaveChanges();
            }
            else
            {
                MessageBox.Show("Mật Khẩu Không Trùng Nhau");
            }
            
        }
        private void button2_Click(object sender, EventArgs e)
        {
           
            this.Dispose();
            this.Close();
        }
    }
}
