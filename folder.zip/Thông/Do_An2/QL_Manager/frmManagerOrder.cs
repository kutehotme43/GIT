﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Do_An2
{
    public partial class frmManagerOrder : Form
    {
        public frmManagerOrder(int IDManager)
        {
            InitializeComponent();
            _idquanly = IDManager;
            LoadAllCompany();
            KhoiTaoThongTinDatagridviewNguyenLieu();
        }
        #region khai báo biến
        private bool addButtonForDGVCompany = false;
        private bool addButtonForDGVSource = false;
        private int _idquanly;
        private DateTime _ngaydathang = DateTime.Now;
        private List<DONDATNGUYENLIEU> listDonDatNguyenLieu = new List<DONDATNGUYENLIEU>();
        private DataTable dtSource = new DataTable();
        #endregion
        #region phương thức
        private void LoadAllCompany()
        {
            try
            {
                Model1 db = new Model1();
                var CompanyList = (from company in db.NhaCungCap
                                   join nguyenlieu in db.NguyenLieu on company.IdNguyenLieu equals nguyenlieu.IdNguyenLieu
                                   orderby company.NgayDangKy descending
                                   select new
                                   {
                                       MaNhaCungCap = company.IdNhaCungCap,
                                       NhaCungCap = company.TenNhaCungCap,
                                       NguyenLieu = nguyenlieu.TenNguyenLieu + " (" + nguyenlieu.DonViTinh + ")",
                                       DonGia = company.Gia,
                                       hiddenIdNguyenLieu = company.IdNguyenLieu
                                   }).ToList();
                dgvAllCompany.DataSource = CompanyList;
                dgvAllCompany.Columns["hiddenIdNguyenLieu"].Visible = false;

                if (!addButtonForDGVCompany)
                {
                    DataGridViewTextBoxColumn soluong = new DataGridViewTextBoxColumn();
                    soluong.HeaderText = "SoLuong";
                    soluong.Name = "txtSoLuong";
                    dgvAllCompany.Columns.Add(soluong);
                    DataGridViewButtonColumn choose = new DataGridViewButtonColumn();
                    choose.HeaderText = "";
                    choose.Text = "Chọn";
                    choose.Name = "btnChooseSource";
                    choose.UseColumnTextForButtonValue = true;
                    dgvAllCompany.Columns.Add(choose);
                    addButtonForDGVCompany = true;
                }
                dgvAllCompany.RowHeadersVisible = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Có lỗi xảy ra. Vui lòng kiểm tra lại! \n Thông tin lỗi:" + ex.Message, "Thông báo lỗi");
            }
        }

        private void HienThiThongTinDatHang()
        {
            lbIdManager.Text = _idquanly.ToString();
            lbMaDonHang.Text = txtOrder.Text.Trim();
            lbThoiHan.Text = txtThoiHan.Text.Trim() + " (ngày)";
        }

        private void KhoiTaoThongTinDatagridviewNguyenLieu()
        {
            dtSource.Columns.Add("NhaCungCap", typeof(string));
            dtSource.Columns.Add("NguyenLieu", typeof(string));
            dtSource.Columns.Add("DonGia", typeof(double));
            dtSource.Columns.Add("SoLuong", typeof(string));
            dtSource.Columns.Add("hiddenIdNhaCungCap", typeof(string));
            dtSource.Columns.Add("hiddenIdNguyenLieu", typeof(string));
        }

        private void HienThiThongTinNguyenLieuDaChon(string tennhacungcap, string tennguyenlieu, string dongia, int soluong, string manhacungcap, string idnguyenlieu)
        {
            try
            {
                DataRow dr = dtSource.NewRow();
                dr[0] = tennhacungcap;
                dr[1] = tennguyenlieu;
                dr[2] = dongia;
                dr[3] = soluong;
                dr[4] = manhacungcap;
                dr[5] = idnguyenlieu;

                dtSource.Rows.Add(dr);
                // binding data
                dgvNguyenLieuDatHang.DataSource = dtSource;
                dgvNguyenLieuDatHang.RowHeadersVisible = false;
                dgvNguyenLieuDatHang.AllowUserToAddRows = false;


                dgvNguyenLieuDatHang.Columns["hiddenIdNhaCungCap"].Visible = false;
                dgvNguyenLieuDatHang.Columns["hiddenIdNguyenLieu"].Visible = false;
                if (!addButtonForDGVSource)
                {
                    DataGridViewButtonColumn delete = new DataGridViewButtonColumn();
                    delete.HeaderText = "";
                    delete.Text = "Xóa";
                    delete.Name = "btnDelete";
                    delete.UseColumnTextForButtonValue = true;
                    dgvNguyenLieuDatHang.Columns.Add(delete);
                    addButtonForDGVSource = true;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Có lỗi xảy ra. Vui lòng kiểm tra lại! \n Thông tin lỗi:" + ex.Message, "Thông báo lỗi");
            }
        }
        // Đây là phương thức dùng để đóng form frmCompanyInfo
        // Và hiển thị form frmManagerCompany
        private void BackFormManagerCompany()
        {
            this.Hide();
            frmManager mgManager = new frmManager(_idquanly);
            mgManager.ShowDialog();
        }
        #endregion

        #region event control
        private void dgvAllCompany_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            var senderGrid = (DataGridView)sender;
            try
            {
                string madon = txtOrder.Text.Trim();
                int thoihan = Convert.ToInt32(txtThoiHan.Text.Trim());
                if (madon == string.Empty)
                {
                    MessageBox.Show("Dữ liệu không hợp lệ. \nVui lòng nhập mã đơn hàng! ", "Thông báo lỗi");
                    return;
                }
                if (thoihan < 0)
                {
                    MessageBox.Show("Dữ liệu không hợp lệ. \nVui lòng nhập thời hạn giao hàng (>= 1 (ngày)! ", "Thông báo lỗi");
                    return;
                }
                HienThiThongTinDatHang();
                if (senderGrid.Columns[e.ColumnIndex] is DataGridViewButtonColumn && e.RowIndex >= 0)
                {
                    int soluong = 0; ;
                    if (dgvAllCompany.Rows[e.RowIndex].Cells[0].Value != null)
                    {
                        soluong = Convert.ToInt32(dgvAllCompany.Rows[e.RowIndex].Cells[0].Value.ToString().Trim());
                    }
                    else
                    {
                        MessageBox.Show("Dữ liệu không hợp lệ. \nVui lòng kiểm tra lại số lượng nguyên liệu cần đặt hàng! ", "Thông báo lỗi");
                        return;
                    }
                    string manhacungcap = dgvAllCompany.Rows[e.RowIndex].Cells["MaNhaCungCap"].Value.ToString();
                    string tennhacungcap = dgvAllCompany.Rows[e.RowIndex].Cells["NhaCungCap"].Value.ToString();
                    string idnguyenlieu = dgvAllCompany.Rows[e.RowIndex].Cells["hiddenIdNguyenLieu"].Value.ToString();
                    string tennguyenlieu = dgvAllCompany.Rows[e.RowIndex].Cells["NguyenLieu"].Value.ToString();
                    string dongia = dgvAllCompany.Rows[e.RowIndex].Cells["DonGia"].Value.ToString();
                    // Kiểm tra đã chọn nguyên liệu có trùng hay không
                    if (listDonDatNguyenLieu.Count > 0)
                    {
                        foreach (DONDATNGUYENLIEU xx in listDonDatNguyenLieu)
                        {
                            if (xx.IdNguyenLieu == idnguyenlieu)
                            {
                                MessageBox.Show("Nguyên liệu: " + tennguyenlieu + " đã được chọn. Vui lòng kiểm tra lại!", "Thông báo lỗi");
                                // Không thực hiện tiếp xử lý                                
                                return;
                            }
                        }
                    }
                    DONDATNGUYENLIEU dondatnguyenlieu = new DONDATNGUYENLIEU()
                    {
                        IdDonDatNguyenLieu = madon,
                        idManager = _idquanly,
                        IdNhaCungCap = manhacungcap,
                        IdNguyenLieu = idnguyenlieu,
                        SoLuong = soluong,
                        TrangThai = false,
                        NgayDatHang = _ngaydathang,
                        ThoiHan = thoihan
                    };
                    listDonDatNguyenLieu.Add(dondatnguyenlieu);
                    //Hiển thị thông tin nguyên liệu đã chọn trên datagridview
                    HienThiThongTinNguyenLieuDaChon(tennhacungcap, tennguyenlieu, dongia, soluong, manhacungcap, idnguyenlieu);

                }
            }
            catch (NullReferenceException exNull)
            {
                MessageBox.Show("Dữ liệu không hợp lệ. \nVui lòng kiểm tra lại số lượng nguyên liệu cần đặt hàng! \n Thông tin lỗi: " + exNull.Message, "Thông báo lỗi");
            }
            catch (FormatException exFormat)
            {
                MessageBox.Show("Dữ liệu không hợp lệ. Vui lòng kiểm tra lại thời hạn nhận đơn hàng (là một số nguyên)! \n Thông tin lỗi: " + exFormat.Message, "Thông báo lỗi");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Có lỗi xảy ra. Vui lòng kiểm tra lại! \n Thông tin lỗi:" + ex.Message, "Thông báo lỗi");
            }

        }

        private void dgvNguyenLieuDatHang_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                var senderGrid = (DataGridView)sender;
                if (senderGrid.Columns[e.ColumnIndex] is DataGridViewButtonColumn && e.RowIndex >= 0)
                {
                    string idnhacungcap = dgvNguyenLieuDatHang.Rows[e.RowIndex].Cells["hiddenIdNhaCungCap"].Value.ToString();
                    string idnguyenlieu = dgvNguyenLieuDatHang.Rows[e.RowIndex].Cells["hiddenIdNguyenLieu"].Value.ToString();
                    DONDATNGUYENLIEU dondatnguyenlieu = null;
                    for (int i = dtSource.Rows.Count - 1; i >= 0; i--)
                    {
                        DataRow dr = dtSource.Rows[i];
                        if (dr["hiddenIdNhaCungCap"].ToString() == idnhacungcap &&
                            dr["hiddenIdNguyenLieu"].ToString() == idnguyenlieu)
                        {
                            // xóa row chứa thông tin dữ liệu nguyên liệu
                            dr.Delete();
                            foreach (DONDATNGUYENLIEU x in listDonDatNguyenLieu)
                            {
                                if (idnhacungcap == x.IdNhaCungCap && idnguyenlieu == x.IdNguyenLieu)
                                {
                                    dondatnguyenlieu = x;
                                    // thoát khỏi vòng lặp khi tìm thấy thông tin nguyên liệu cần xóa
                                    break;
                                }
                            }
                            // thoát khỏi vòng lặp khi đã tìm thấy row trong datatable chứa thông tin dữ liệu cần xóa
                            break;
                        }
                    }

                    dtSource.AcceptChanges();
                    listDonDatNguyenLieu.Remove(dondatnguyenlieu);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Có lỗi xảy ra. Vui lòng kiểm tra lại! \n Thông tin lỗi:" + ex.Message, "Thông báo lỗi");
            }
        }


        private void btnOrder_Click(object sender, EventArgs e)
        {
            if (listDonDatNguyenLieu.Count == 0)
            {
                // Không có dữ liệu đơn hàng được đăng ký
                // quay trở lại form.
                return;
            }
            try
            {
                string message = string.Empty;
                var db = new Model1();
                db.DonDatHang.AddRange(listDonDatNguyenLieu);

                // Khi nhấn vào button đăng ký nhà cung cấp (btnRegisterCompany)
                // Vì mất một khoản thời gian đăng ký vào database
                // Nên sẽ vô hiệu hóa 2 button
                btnOrder.Enabled = false;
                db.SaveChanges();
                message += Environment.NewLine;
                message += "Thông tin đơn đặt nguyên liệu: \n"
                                 + "Id quản lý: " + _idquanly
                                 + "Mã đơn hàng: " + txtOrder.Text.Trim()
                                 + "Thời hạn: " + txtThoiHan.Text.Trim() + " (ngày)"
                                 + "\nThông tin nguyên liệu:\n";
                int count = 1;
                foreach (DataRow row in dtSource.Rows)
                {
                    message += Environment.NewLine;
                    message += count + ".";
                    message += Environment.NewLine;
                    message += " Tên nguyên liệu: " + row["NguyenLieu"]
                              + "\n Đơn giá: " + row["DonGia"]
                              + "\n Số lượng: " + row["SoLuong"];
                    count++;
                }
                MessageBox.Show(message, "Thông tin đơn đặt nguyên liệu");
                // Quay trở lại form quản lý nhà cung cấp.
                BackFormManagerCompany();
            }
            catch (Exception ex)
            {               
                MessageBox.Show("Có lỗi xảy ra. Vui lòng kiểm tra lại! \n Thông tin lỗi:\n" + ex.Message, "Thông báo lỗi");
            }
            finally
            {
                btnOrder.Enabled = true;
            }
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            // Quay trở lại form quản lý nhà cung cấp.
            BackFormManagerCompany();
        }

        #endregion

        private void btnFind_Click(object sender, EventArgs e)
        {
            try
            {
                string idNhaCungCap = txtFindIdCompany.Text.Trim();
                Model1 db = new Model1();

                var CompanyList = (from company in db.NhaCungCap
                                   join nguyenlieu in db.NguyenLieu on company.IdNguyenLieu equals nguyenlieu.IdNguyenLieu
                                   where company.IdNhaCungCap.Contains(idNhaCungCap)
                                   orderby company.NgayDangKy descending
                                   select new
                                   {
                                       MaNhaCungCap = company.IdNhaCungCap,
                                       NhaCungCap = company.TenNhaCungCap,
                                       NguyenLieu = nguyenlieu.TenNguyenLieu + " (" + nguyenlieu.DonViTinh + ")",
                                       DonGia = company.Gia,
                                       hiddenIdNguyenLieu = company.IdNguyenLieu
                                   }).ToList();

                dgvAllCompany.DataSource = CompanyList;
                dgvAllCompany.Refresh();
                dgvAllCompany.Columns["hiddenIdNguyenLieu"].Visible = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Có lỗi xảy ra. Vui lòng kiểm tra lại! \n Thông tin lỗi:" + ex.Message, "Thông báo lỗi");
            }
        }

        private void btnFindCompanyName_Click(object sender, EventArgs e)
        {
            try
            {
                string TenNhaCungCap = txtFindCompanyName.Text.Trim();
                Model1 db = new Model1();

                var CompanyList = (from company in db.NhaCungCap
                                   join nguyenlieu in db.NguyenLieu on company.IdNguyenLieu equals nguyenlieu.IdNguyenLieu
                                   where company.TenNhaCungCap.Contains(TenNhaCungCap)
                                   orderby company.NgayDangKy descending
                                   select new
                                   {
                                       MaNhaCungCap = company.IdNhaCungCap,
                                       NhaCungCap = company.TenNhaCungCap,
                                       NguyenLieu = nguyenlieu.TenNguyenLieu + " (" + nguyenlieu.DonViTinh + ")",
                                       DonGia = company.Gia,
                                       hiddenIdNguyenLieu = company.IdNguyenLieu
                                   }).ToList();


                dgvAllCompany.DataSource = CompanyList;
                dgvAllCompany.Refresh();
                dgvAllCompany.Columns["hiddenIdNguyenLieu"].Visible = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Có lỗi xảy ra. Vui lòng kiểm tra lại! \n Thông tin lỗi:" + ex.Message, "Thông báo lỗi");
            }
        }

        private void btnTimNguyenLieu_Click(object sender, EventArgs e)
        {
            try
            {
                string tennguyenlieu = txtFindNguyenLieu.Text.Trim();
                Model1 db = new Model1();
                var CompanyList = (from company in db.NhaCungCap
                                   join nguyenlieu in db.NguyenLieu on company.IdNguyenLieu equals nguyenlieu.IdNguyenLieu
                                   where nguyenlieu.TenNguyenLieu.Contains(tennguyenlieu)
                                   orderby company.NgayDangKy descending
                                   select new
                                   {
                                       MaNhaCungCap = company.IdNhaCungCap,
                                       NhaCungCap = company.TenNhaCungCap,
                                       NguyenLieu = nguyenlieu.TenNguyenLieu + " (" + nguyenlieu.DonViTinh + ")",
                                       DonGia = company.Gia,
                                       hiddenIdNguyenLieu = company.IdNguyenLieu
                                   }).ToList();
                dgvAllCompany.DataSource = CompanyList;
                dgvAllCompany.Refresh();
                dgvAllCompany.Columns["hiddenIdNguyenLieu"].Visible = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Có lỗi xảy ra. Vui lòng kiểm tra lại! \n Thông tin lỗi:" + ex.Message, "Thông báo lỗi");
            }
        }
    }
}
