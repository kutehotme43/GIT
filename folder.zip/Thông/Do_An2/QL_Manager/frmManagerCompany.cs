﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Do_An2
{
    public partial class frmManagerCompany : Form
    {
        private DataTable dtSource = new DataTable();
        private Dictionary<string, double> dicDanhSachChonNguyenLieu = new Dictionary<string, double>();
        private List<string> lstDanhSachIDNguyenLieu = new List<string>();
        private bool addButtonForDGVSource = false;
        private bool addButtonForDGVCompany = false;
        private List<NHACUNGCAP> arrNhaCungCap = new List<NHACUNGCAP>();
        private int _idquanly;
        public frmManagerCompany(int IDManager)
        {
            InitializeComponent();
            _idquanly = IDManager;
            fillDataComboSource();
            // Intial header for datatable (nguyenlieu)
            InitDataTableSource();
            LoadAllCompany();
        }

        private void InitDataTableSource()
        {
            dtSource.Columns.Add("MaNguyenLieu", typeof(string));
            dtSource.Columns.Add("ThongTinNguyenLieu", typeof(string));
            dtSource.Columns.Add("DonGia", typeof(double));
        }
        private void LoadAllCompany()
        {
            try
            {
                Model1 db = new Model1();
                var CompanyList = (from company in db.NhaCungCap
                                   join nguyenlieu in db.NguyenLieu on company.IdNguyenLieu equals nguyenlieu.IdNguyenLieu
                                   orderby company.NgayDangKy descending
                                   select new
                                   {
                                       MaNhaCungCap = company.IdNhaCungCap,
                                       TenCongTy = company.TenNhaCungCap,
                                       DiaChiCongTy = company.DiaChi,
                                       SDT = company.SoDienThoai,
                                       NguyenLieu = nguyenlieu.TenNguyenLieu + " (" + nguyenlieu.DonViTinh + ")",
                                       DonGia = company.Gia,
                                       DangKy = company.NgayDangKy,
                                       hiddenIdNguyenLieu = company.IdNguyenLieu
                                   }).ToList();
                dgvAllCompany.DataSource = CompanyList;
                dgvAllCompany.Columns["hiddenIdNguyenLieu"].Visible = false;

                if (!addButtonForDGVCompany)
                {
                    DataGridViewCheckBoxColumn optionDelete = new DataGridViewCheckBoxColumn();
                    optionDelete.ValueType = typeof(bool);
                    optionDelete.Name = "ckDelete";
                    optionDelete.HeaderText = "Xóa";
                    dgvAllCompany.Columns.Add(optionDelete);
                    DataGridViewButtonColumn edit = new DataGridViewButtonColumn();
                    edit.HeaderText = "Sửa";
                    edit.Text = "Chỉnh sửa";
                    edit.Name = "btnEditCompany";
                    edit.UseColumnTextForButtonValue = true;
                    dgvAllCompany.Columns.Add(edit);
                    addButtonForDGVCompany = true;
                }

                dgvAllCompany.RowHeadersVisible = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Có lỗi xảy ra. Vui lòng kiểm tra lại! \n Thông tin lỗi:" + ex.Message, "Thông báo lỗi");
            }
        }

        private void fillDataComboSource()
        {
            try
            {
                Model1 db = new Model1();
                var SourceList = (from sources in db.NguyenLieu
                                  select new
                                  {
                                      MaNguyenLieu = sources.IdNguyenLieu,
                                      ThongTinNguyenLieu = sources.TenNguyenLieu + " (" + sources.DonViTinh + ")"
                                  }).ToList();


                cbSource.DataSource = SourceList;
                cbSource.ValueMember = "MaNguyenLieu";
                cbSource.DisplayMember = "ThongTinNguyenLieu";
                // Không cho người dùng nhập dữ liệu vào combox
                cbSource.DropDownStyle = ComboBoxStyle.DropDownList;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Có lỗi xảy ra. Vui lòng kiểm tra lại! \n Thông tin lỗi:" + ex.Message, "Thông báo lỗi");
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (dicDanhSachChonNguyenLieu.ContainsKey(cbSource.SelectedValue.ToString()))
            {
                MessageBox.Show("Nguyên liệu đã được chọn. Vui lòng kiểm tra!", "Thông báo lỗi");
                return;
            }
            // 1. cbSource.SelectedValue.ToString()
            // 2. cbSource.Text
            // 3. txtPrice.Text
            // => dgvAllSource    
            try
            {
                Console.WriteLine("1:" + cbSource.SelectedValue.ToString());
                DataRow dr = dtSource.NewRow();
                dr[0] = cbSource.SelectedValue.ToString();
                dr[1] = cbSource.Text;
                dr[2] = txtPrice.Text;

                dtSource.Rows.Add(dr);
                // binding data
                dgvAllSource.DataSource = dtSource;
                dgvAllSource.RowHeadersVisible = false;
                dgvAllSource.AllowUserToAddRows = false;
                if (!addButtonForDGVSource)
                {
                    DataGridViewButtonColumn delete = new DataGridViewButtonColumn();
                    delete.HeaderText = "";
                    delete.Text = "Xóa";
                    delete.Name = "btnDelete";
                    delete.UseColumnTextForButtonValue = true;
                    dgvAllSource.Columns.Add(delete);
                    addButtonForDGVSource = true;
                }

                // add IdNguyenLieu into "dicDanhSachChonNguyenLieu"
                dicDanhSachChonNguyenLieu.Add(cbSource.SelectedValue.ToString(), Convert.ToDouble(txtPrice.Text));
                // add 
                lstDanhSachIDNguyenLieu.Add(cbSource.SelectedValue.ToString());
            }
            catch (ArgumentException exFormat)
            {
                MessageBox.Show("Dữ liệu không hợp lệ. Vui lòng kiểm tra lại! \n Thông tin lỗi: " + exFormat.Message, "Thông báo lỗi");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Có lỗi xảy ra. Vui lòng kiểm tra lại! \n Thông tin lỗi:" + ex.Message, "Thông báo lỗi");
            }

        }

        private void btnRegisterCompany_Click(object sender, EventArgs e)
        {
            string idnhacungcap = txtIDCompany.Text.Trim();
            string tennhacungcap = txtCompanyName.Text.Trim();
            string diachinhacungcap = txtAddress.Text.Trim();
            string sodienthoai = txtPhone.Text.Trim();
            if (idnhacungcap == string.Empty)
            {
                // hiển thị thông báo lỗi và dừng thực hiện đăng ký.
                MessageBox.Show("Vui lòng nhập mã nhà cung cấp!", "Thông báo lỗi");
                return;
            }
            if (tennhacungcap == string.Empty)
            {
                // hiển thị thông báo lỗi và dừng thực hiện đăng ký.
                MessageBox.Show("Vui lòng nhập tên nhà cung cấp!", "Thông báo lỗi");
                return;
            }
            try
            {
                var db = new Model1();
                List<NHACUNGCAP> listCompany = new List<NHACUNGCAP>();
                foreach (KeyValuePair<string, double> source in dicDanhSachChonNguyenLieu)
                {
                    var company = new NHACUNGCAP
                    {
                        IdNhaCungCap = idnhacungcap,
                        TenNhaCungCap = tennhacungcap,
                        DiaChi = diachinhacungcap,
                        SoDienThoai = sodienthoai,
                        IdNguyenLieu = source.Key,
                        Gia = source.Value,
                        NgayDangKy = DateTime.Now
                    };
                    listCompany.Add(company);
                }

                if (listCompany.Count == 0)
                {
                    // hiển thị thông báo lỗi và dừng thực hiện đăng ký.
                    MessageBox.Show("Vui lòng nhập nguyên liệu của nhà cung cấp!", "Thông báo lỗi");
                    return;
                }
                db.NhaCungCap.AddRange(listCompany);

                // Khi nhấn vào button đăng ký nhà cung cấp (btnRegisterCompany)
                // Vì mất một khoản thời gian đăng ký vào database
                // Nên sẽ vô hiệu hóa 2 button
                btnSave.Enabled = false;
                btnRegisterCompany.Enabled = false;
                db.SaveChanges();
                MessageBox.Show("Đăng ký thành công nhà cung cấp mới", "Thông báo");
                // xóa dữ liệu cũ
                txtIDCompany.Text = "";
                txtCompanyName.Text = "";
                txtAddress.Text = "";
                txtPhone.Text = "";
                txtPrice.Text = "";
                dgvAllSource.DataSource = null;
                dgvAllSource.Columns.Clear();
                addButtonForDGVSource = false;
                dtSource.Rows.Clear();
                dicDanhSachChonNguyenLieu.Clear();
                lstDanhSachIDNguyenLieu.Clear();

                // load dữ liệu vừa cập nhật
                LoadAllCompany();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Có lỗi xảy ra. Vui lòng kiểm tra lại! \n Thông tin lỗi:" + ex.Message, "Thông báo lỗi");
            }
            finally
            {
                // Sau khi cập nhật dữ liệu vào database
                // Thì kích hoạt lại 2 button
                btnSave.Enabled = true;
                btnRegisterCompany.Enabled = true;
            }
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Hide();
            frmManager mgManager = new frmManager(_idquanly);
            mgManager.ShowDialog();
        }

        private void dgvAllSource_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                var senderGrid = (DataGridView)sender;
                if (senderGrid.Columns[e.ColumnIndex] is DataGridViewButtonColumn && e.RowIndex >= 0)
                {
                    string IdNguyenLieu = lstDanhSachIDNguyenLieu[e.RowIndex];
                    for (int i = dtSource.Rows.Count - 1; i >= 0; i--)
                    {
                        DataRow dr = dtSource.Rows[i];
                        if (dr["MaNguyenLieu"].ToString() == IdNguyenLieu)
                        {
                            dr.Delete();
                            dicDanhSachChonNguyenLieu.Remove(IdNguyenLieu);
                            lstDanhSachIDNguyenLieu.Remove(IdNguyenLieu);
                        }

                    }
                    dtSource.AcceptChanges();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Có lỗi xảy ra. Vui lòng kiểm tra lại! \n Thông tin lỗi:" + ex.Message, "Thông báo lỗi");
            }
        }

        private void btnDeleteCompanySelect_Click(object sender, EventArgs e)
        {
            try
            {
                var db = new Model1();
                string message = string.Empty;
                List<NHACUNGCAP> listCompany = new List<NHACUNGCAP>();
                foreach (DataGridViewRow row in dgvAllCompany.Rows)
                {
                    bool isSelected = Convert.ToBoolean(row.Cells["ckDelete"].Value);
                    if (isSelected)
                    {
                        var company = new NHACUNGCAP
                        {
                            IdNhaCungCap = row.Cells["MaNhaCungCap"].Value.ToString(),
                            IdNguyenLieu = row.Cells["hiddenIdNguyenLieu"].Value.ToString(),
                        };
                        db.NhaCungCap.Attach(company);
                        listCompany.Add(company);
                        message += Environment.NewLine;
                        message += row.Cells["TenCongTy"].Value.ToString() + " cung cấp nguyên liệu: " + row.Cells["NguyenLieu"].Value.ToString();
                    }
                }

                db.NhaCungCap.RemoveRange(listCompany);
                db.SaveChanges();
                LoadAllCompany();
                MessageBox.Show("Thông tin các nguyên liệu của nhà cung cấp đã được xóa:" + message);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Có lỗi xảy ra. Vui lòng kiểm tra lại! \n Thông tin lỗi:" + ex.Message, "Thông báo lỗi");
            }
        }

        private void btnFind_Click(object sender, EventArgs e)
        {
            try
            {
                string idNhaCungCap = txtFindIdCompany.Text.Trim();
                Model1 db = new Model1();
                var CompanyList = (from company in db.NhaCungCap
                                   join nguyenlieu in db.NguyenLieu on company.IdNguyenLieu equals nguyenlieu.IdNguyenLieu
                                   where company.IdNhaCungCap.Contains(idNhaCungCap)
                                   orderby company.NgayDangKy descending
                                   select new
                                   {
                                       MaNhaCungCap = company.IdNhaCungCap,
                                       TenCongTy = company.TenNhaCungCap,
                                       DiaChiCongTy = company.DiaChi,
                                       SDT = company.SoDienThoai,
                                       NguyenLieu = nguyenlieu.TenNguyenLieu + " (" + nguyenlieu.DonViTinh + ")",
                                       DonGia = company.Gia,
                                       DangKy = company.NgayDangKy,
                                       hiddenIdNguyenLieu = company.IdNguyenLieu
                                   }).ToList();
                dgvAllCompany.DataSource = CompanyList;
                dgvAllCompany.Refresh();
                dgvAllCompany.Columns["hiddenIdNguyenLieu"].Visible = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Có lỗi xảy ra. Vui lòng kiểm tra lại! \n Thông tin lỗi:" + ex.Message, "Thông báo lỗi");
            }
        }

        private void btnFindCompanyName_Click(object sender, EventArgs e)
        {
            try
            {
                string TenNhaCungCap = txtFindCompanyName.Text.Trim();
                Model1 db = new Model1();
                var CompanyList = (from company in db.NhaCungCap
                                   join nguyenlieu in db.NguyenLieu on company.IdNguyenLieu equals nguyenlieu.IdNguyenLieu
                                   where company.TenNhaCungCap.Contains(TenNhaCungCap)
                                   orderby company.NgayDangKy descending
                                   select new
                                   {
                                       MaNhaCungCap = company.IdNhaCungCap,
                                       TenCongTy = company.TenNhaCungCap,
                                       DiaChiCongTy = company.DiaChi,
                                       SDT = company.SoDienThoai,
                                       NguyenLieu = nguyenlieu.TenNguyenLieu + " (" + nguyenlieu.DonViTinh + ")",
                                       DonGia = company.Gia,
                                       DangKy = company.NgayDangKy,
                                       hiddenIdNguyenLieu = company.IdNguyenLieu
                                   }).ToList();
                dgvAllCompany.DataSource = CompanyList;
                dgvAllCompany.Refresh();
                dgvAllCompany.Columns["hiddenIdNguyenLieu"].Visible = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Có lỗi xảy ra. Vui lòng kiểm tra lại! \n Thông tin lỗi:" + ex.Message, "Thông báo lỗi");
            }
        }

        private void dgvAllCompany_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.ColumnIndex == 1)
                {
                    string idNhaCungCap = dgvAllCompany.Rows[e.RowIndex].Cells[2].Value.ToString();
                    /*
                    string tenCongTy = dgvAllCompany.Rows[e.RowIndex].Cells[3].Value.ToString();
                    string diaChiCongTy = dgvAllCompany.Rows[e.RowIndex].Cells[4].Value.ToString();
                    string SDT = dgvAllCompany.Rows[e.RowIndex].Cells[5].Value.ToString();
                    string idNguyenLieu = dgvAllCompany.Rows[e.RowIndex].Cells[9].Value.ToString();
                    string donGia = dgvAllCompany.Rows[e.RowIndex].Cells[7].Value.ToString();
                    string ngayDangKy = dgvAllCompany.Rows[e.RowIndex].Cells[8].Value.ToString();
                    */
                    this.Hide();
                    frmCompanyInfo companyInfo = new frmCompanyInfo(_idquanly, idNhaCungCap);
                    companyInfo.ShowDialog();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Có lỗi xảy ra. Vui lòng kiểm tra lại! \n Thông tin lỗi:" + ex.Message, "Thông báo lỗi");
            }
        }
    }

}
