﻿namespace Do_An2
{
    partial class frmManagerOrder
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.btnTimNguyenLieu = new System.Windows.Forms.Button();
            this.btnFindCompanyName = new System.Windows.Forms.Button();
            this.btnFind = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.dgvAllCompany = new System.Windows.Forms.DataGridView();
            this.label8 = new System.Windows.Forms.Label();
            this.txtFindNguyenLieu = new System.Windows.Forms.TextBox();
            this.txtFindCompanyName = new System.Windows.Forms.TextBox();
            this.txtFindIdCompany = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtThoiHan = new System.Windows.Forms.TextBox();
            this.txtOrder = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.lbMaDonHang = new System.Windows.Forms.Label();
            this.lbIdManager = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.dgvNguyenLieuDatHang = new System.Windows.Forms.DataGridView();
            this.lbThoiHan = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.btnOrder = new System.Windows.Forms.Button();
            this.btnBack = new System.Windows.Forms.Button();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAllCompany)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvNguyenLieuDatHang)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(212)))), ((int)(((byte)(29)))));
            this.groupBox3.Controls.Add(this.btnTimNguyenLieu);
            this.groupBox3.Controls.Add(this.btnFindCompanyName);
            this.groupBox3.Controls.Add(this.btnFind);
            this.groupBox3.Controls.Add(this.label4);
            this.groupBox3.Controls.Add(this.label9);
            this.groupBox3.Controls.Add(this.dgvAllCompany);
            this.groupBox3.Controls.Add(this.label8);
            this.groupBox3.Controls.Add(this.txtFindNguyenLieu);
            this.groupBox3.Controls.Add(this.txtFindCompanyName);
            this.groupBox3.Controls.Add(this.txtFindIdCompany);
            this.groupBox3.Location = new System.Drawing.Point(27, 156);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(855, 381);
            this.groupBox3.TabIndex = 7;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Danh sách nhà cung cấp nguyên liệu";
            // 
            // btnTimNguyenLieu
            // 
            this.btnTimNguyenLieu.Location = new System.Drawing.Point(473, 94);
            this.btnTimNguyenLieu.Name = "btnTimNguyenLieu";
            this.btnTimNguyenLieu.Size = new System.Drawing.Size(75, 23);
            this.btnTimNguyenLieu.TabIndex = 4;
            this.btnTimNguyenLieu.Text = "Tìm";
            this.btnTimNguyenLieu.UseVisualStyleBackColor = true;
            this.btnTimNguyenLieu.Click += new System.EventHandler(this.btnTimNguyenLieu_Click);
            // 
            // btnFindCompanyName
            // 
            this.btnFindCompanyName.Location = new System.Drawing.Point(473, 61);
            this.btnFindCompanyName.Name = "btnFindCompanyName";
            this.btnFindCompanyName.Size = new System.Drawing.Size(75, 23);
            this.btnFindCompanyName.TabIndex = 4;
            this.btnFindCompanyName.Text = "Tìm";
            this.btnFindCompanyName.UseVisualStyleBackColor = true;
            this.btnFindCompanyName.Click += new System.EventHandler(this.btnFindCompanyName_Click);
            // 
            // btnFind
            // 
            this.btnFind.Location = new System.Drawing.Point(473, 29);
            this.btnFind.Name = "btnFind";
            this.btnFind.Size = new System.Drawing.Size(75, 23);
            this.btnFind.TabIndex = 4;
            this.btnFind.Text = "Tìm";
            this.btnFind.UseVisualStyleBackColor = true;
            this.btnFind.Click += new System.EventHandler(this.btnFind_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(29, 96);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(168, 17);
            this.label4.TabIndex = 2;
            this.label4.Text = "Tìm theo tên nguyên liệu:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(29, 65);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(181, 17);
            this.label9.TabIndex = 2;
            this.label9.Text = "Tìm theo tên nhà cung cấp:";
            // 
            // dgvAllCompany
            // 
            this.dgvAllCompany.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvAllCompany.Location = new System.Drawing.Point(28, 140);
            this.dgvAllCompany.Name = "dgvAllCompany";
            this.dgvAllCompany.RowHeadersWidth = 51;
            this.dgvAllCompany.RowTemplate.Height = 24;
            this.dgvAllCompany.Size = new System.Drawing.Size(798, 206);
            this.dgvAllCompany.TabIndex = 0;
            this.dgvAllCompany.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvAllCompany_CellContentClick);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(29, 32);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(180, 17);
            this.label8.TabIndex = 2;
            this.label8.Text = "Tìm theo mã nhà cung cấp:";
            // 
            // txtFindNguyenLieu
            // 
            this.txtFindNguyenLieu.Location = new System.Drawing.Point(229, 96);
            this.txtFindNguyenLieu.Name = "txtFindNguyenLieu";
            this.txtFindNguyenLieu.Size = new System.Drawing.Size(223, 22);
            this.txtFindNguyenLieu.TabIndex = 5;
            // 
            // txtFindCompanyName
            // 
            this.txtFindCompanyName.Location = new System.Drawing.Point(229, 62);
            this.txtFindCompanyName.Name = "txtFindCompanyName";
            this.txtFindCompanyName.Size = new System.Drawing.Size(223, 22);
            this.txtFindCompanyName.TabIndex = 4;
            // 
            // txtFindIdCompany
            // 
            this.txtFindIdCompany.Location = new System.Drawing.Point(229, 29);
            this.txtFindIdCompany.Name = "txtFindIdCompany";
            this.txtFindIdCompany.Size = new System.Drawing.Size(223, 22);
            this.txtFindIdCompany.TabIndex = 3;
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(212)))), ((int)(((byte)(29)))));
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.txtThoiHan);
            this.groupBox1.Controls.Add(this.txtOrder);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Location = new System.Drawing.Point(27, 81);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(855, 79);
            this.groupBox1.TabIndex = 6;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Đặt hàng";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(29, 40);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(95, 17);
            this.label5.TabIndex = 2;
            this.label5.Text = "Mã đơn hàng:";
            // 
            // txtThoiHan
            // 
            this.txtThoiHan.Location = new System.Drawing.Point(465, 33);
            this.txtThoiHan.Name = "txtThoiHan";
            this.txtThoiHan.Size = new System.Drawing.Size(248, 22);
            this.txtThoiHan.TabIndex = 2;
            // 
            // txtOrder
            // 
            this.txtOrder.Location = new System.Drawing.Point(153, 35);
            this.txtOrder.Name = "txtOrder";
            this.txtOrder.Size = new System.Drawing.Size(189, 22);
            this.txtOrder.TabIndex = 1;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(735, 35);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(49, 17);
            this.label11.TabIndex = 2;
            this.label11.Text = "(ngày)";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(365, 38);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(68, 17);
            this.label3.TabIndex = 2;
            this.label3.Text = "Thời hạn:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(37, 40);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(95, 17);
            this.label2.TabIndex = 2;
            this.label2.Text = "Mã đơn hàng:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(174, -108);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(731, 51);
            this.label1.TabIndex = 5;
            this.label1.Text = "Quản Lý Nhà Cung Cấp Nguyên Liệu";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(650, 9);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(548, 51);
            this.label10.TabIndex = 9;
            this.label10.Text = "Quản Đơn Đặt Nguyên Liệu";
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(212)))), ((int)(((byte)(29)))));
            this.groupBox2.Controls.Add(this.lbMaDonHang);
            this.groupBox2.Controls.Add(this.lbIdManager);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.groupBox4);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.lbThoiHan);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Location = new System.Drawing.Point(943, 81);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(817, 456);
            this.groupBox2.TabIndex = 10;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Chi tiết đơn đặt hàng";
            // 
            // lbMaDonHang
            // 
            this.lbMaDonHang.AutoSize = true;
            this.lbMaDonHang.Location = new System.Drawing.Point(147, 38);
            this.lbMaDonHang.Name = "lbMaDonHang";
            this.lbMaDonHang.Size = new System.Drawing.Size(20, 17);
            this.lbMaDonHang.TabIndex = 2;
            this.lbMaDonHang.Text = "...";
            // 
            // lbIdManager
            // 
            this.lbIdManager.AutoSize = true;
            this.lbIdManager.Location = new System.Drawing.Point(555, 40);
            this.lbIdManager.Name = "lbIdManager";
            this.lbIdManager.Size = new System.Drawing.Size(20, 17);
            this.lbIdManager.TabIndex = 2;
            this.lbIdManager.Text = "...";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(476, 40);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(73, 17);
            this.label7.TabIndex = 2;
            this.label7.Text = "Id quản lý:";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.dgvNguyenLieuDatHang);
            this.groupBox4.Location = new System.Drawing.Point(40, 75);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(750, 374);
            this.groupBox4.TabIndex = 7;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Danh sách nguyên liệu đặt hàng";
            // 
            // dgvNguyenLieuDatHang
            // 
            this.dgvNguyenLieuDatHang.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvNguyenLieuDatHang.Location = new System.Drawing.Point(32, 29);
            this.dgvNguyenLieuDatHang.Name = "dgvNguyenLieuDatHang";
            this.dgvNguyenLieuDatHang.RowHeadersWidth = 51;
            this.dgvNguyenLieuDatHang.RowTemplate.Height = 24;
            this.dgvNguyenLieuDatHang.Size = new System.Drawing.Size(681, 317);
            this.dgvNguyenLieuDatHang.TabIndex = 0;
            // 
            // lbThoiHan
            // 
            this.lbThoiHan.AutoSize = true;
            this.lbThoiHan.Location = new System.Drawing.Point(346, 40);
            this.lbThoiHan.Name = "lbThoiHan";
            this.lbThoiHan.Size = new System.Drawing.Size(20, 17);
            this.lbThoiHan.TabIndex = 2;
            this.lbThoiHan.Text = "...";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(256, 40);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(68, 17);
            this.label6.TabIndex = 2;
            this.label6.Text = "Thời hạn:";
            // 
            // btnOrder
            // 
            this.btnOrder.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnOrder.Location = new System.Drawing.Point(943, 574);
            this.btnOrder.Name = "btnOrder";
            this.btnOrder.Size = new System.Drawing.Size(227, 34);
            this.btnOrder.TabIndex = 8;
            this.btnOrder.Text = "Đặt hàng";
            this.btnOrder.UseVisualStyleBackColor = true;
            this.btnOrder.Click += new System.EventHandler(this.btnOrder_Click);
            // 
            // btnBack
            // 
            this.btnBack.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBack.Location = new System.Drawing.Point(655, 574);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(227, 34);
            this.btnBack.TabIndex = 11;
            this.btnBack.Text = "Trở lại trang quản lý";
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // frmManagerOrder
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(177)))), ((int)(((byte)(124)))), ((int)(((byte)(80)))));
            this.ClientSize = new System.Drawing.Size(1783, 734);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.btnOrder);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label1);
            this.Name = "frmManagerOrder";
            this.Text = "Thông tin đơn đặt nguyên liệu";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAllCompany)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvNguyenLieuDatHang)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button btnFindCompanyName;
        private System.Windows.Forms.Button btnFind;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.DataGridView dgvAllCompany;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtFindCompanyName;
        private System.Windows.Forms.TextBox txtFindIdCompany;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtThoiHan;
        private System.Windows.Forms.TextBox txtOrder;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button btnTimNguyenLieu;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtFindNguyenLieu;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label lbMaDonHang;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lbThoiHan;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lbIdManager;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.DataGridView dgvNguyenLieuDatHang;
        private System.Windows.Forms.Button btnOrder;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button btnBack;
    }
}