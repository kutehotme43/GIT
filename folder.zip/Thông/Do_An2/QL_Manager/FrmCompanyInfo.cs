﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Do_An2
{
    public partial class frmCompanyInfo : Form
    {
        private int _idquanly;
        public frmCompanyInfo(int IDManager, string idNhaCungCap)
        {
            InitializeComponent();
            _idquanly = IDManager;
            ShowCompany(idNhaCungCap);
        }

        #region Event control (sự kiện các đối tượng)
        // event cập nhật thông tin nhà cung cấp
        // bao gồm: tên nhà cung cấp, địa chỉ, số điện thoại
        //          thông tin nguyên liệu (id nguyên liệu, tên nguyên liệu, đơn giá)
        // 
        // Input:
        //  - _danhsachnguyenlieu_goc: Danh sách nguyên liệu ban đầu
        //  - _danhsachnguyenlieu_thaydoi: Danh sách nguyên liệu sau khi chỉnh sửa.
        // Thực hiện: 
        //   1. insert , update dữ liệu nhà cung cấp
        //   2. delete nguyên liệu của nhà cung cấp
        //   3. Hiển thị message thông báo dữ liệu thay đổi của nhà cung cấp.
        private void btnUpdateCompany_Click(object sender, EventArgs e)
        {
            try
            {
                string message = string.Empty;
                string idnhacungcap = txtIDCompany.Text;
                string tennhacungcap = txtCompanyName.Text;
                string sodienthoai = txtPhone.Text;
                string diachi = txtAddress.Text;
                // Kiểm tra có cập nhật thông tin Tên Nhà Cung Cấp, Địa Chỉ, Số Điện Thoại hay không?
                bool thaydoithongtin_nhacungcap = (_tennhacungcap_goc != tennhacungcap
                                                   || _diachi_goc != diachi
                                                   || _phone_goc != sodienthoai);
                // Vì quá trình cập nhật dữ liệu mất 1 khoảng thời gian
                // Nên khi click chuột vào button này
                // Thì thực hiện vô hiệu hóa chức năng click của button này.
                // đồng thời vô hiệu hóa button đăng ký nguyên liệu
                btnUpdateCompany.Enabled = false;
                btnSave.Enabled = false;
                // TODO
                // - Những nguyên liệu không chỉnh sửa đơn giá không thực hiện update
                //   Ngược lại thì update đơn giá.
                // - Những nguyên liệu thêm mới thì thực hiện Insert
                // - Những nguyên liệu bị loại bỏ thì thực hiện hiện Delete    
                // TODO 1: gọi phương thức insert , update dữ liệu nhà cung cấp
                Model1 db = new Model1();
                message += CapNhatDuLieuNhaCungCap(db, idnhacungcap, tennhacungcap, sodienthoai, diachi, thaydoithongtin_nhacungcap);
                // TODO 2: gọi phương thức delete nguyên liệu của nhà cung cấp
                message += XoaNguyenLieuNhaCungCap(db, idnhacungcap);

                // Nếu mà có thay đổi thông tin nhà cung cấp hoặc thêm/ sửa/ xóa nguyên liệu
                // Thì hiển thị thông tin message.
                if (message != string.Empty)
                {
                    // Nếu mà không có thay đổi thông tin nhà cung cấp
                    // Thì bổ sung vào message thông tin nhà cung cấp 
                    if (thaydoithongtin_nhacungcap)
                    {
                        message = Environment.NewLine
                                  + "Mã nhà cung cấp: " + idnhacungcap
                                  + Environment.NewLine
                                  + "Thông tin cập nhật:"
                                  + Environment.NewLine
                                  + " Tên nhà cung cấp: " + tennhacungcap
                                  + Environment.NewLine
                                  + " Địa chỉ: " + diachi
                                  + Environment.NewLine
                                  + " Số điện thoại: " + sodienthoai
                                  + Environment.NewLine
                                  + message;
                    }
                    else
                    {
                        message = Environment.NewLine
                                 + "Mã nhà cung cấp: " + idnhacungcap
                                 + Environment.NewLine
                                 + "Thông tin cập nhật:"
                                 + message;
                    }

                    MessageBox.Show(message);
                }
                // Quay trở lại form quản lý nhà cung cấp.
                BackFormManagerCompany();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Có lỗi xảy ra. Vui lòng kiểm tra lại! \n Thông tin lỗi:" + ex.Message, "Thông báo lỗi");
            }
        }

        // event thêm nút "xóa" vào datagridview danh mục nguyên liệu (dgvAllSource)
        // Khi kích vào nút "xóa"
        // Thì thực hiện xóa dữ liệu nguyên liệu (id nguyên liệu, tên nguyên liệu, đơn giá) ra khỏi dgvAllSource.
        // Ngoài ra:
        //     1: Xoa thong tin nguyen lieu khoi danh sach chon 
        //     2: Xoa thong tin nguyen lieu khoi datagridview dgvAllSource.
        private void dgvAllSource_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                var senderGrid = (DataGridView)sender;
                if (senderGrid.Columns[e.ColumnIndex] is DataGridViewButtonColumn && e.RowIndex >= 0)
                {
                    string idNguyenLieu = dgvAllSource.Rows[e.RowIndex].Cells["MaNguyenLieu"].Value.ToString();
                    //TODO:
                    // 1: Xoa thong tin nguyen lieu khoi danh sach chon 
                    // 2: Xoa thong tin nguyen lieu khoi datagridview dgvAllSource.
                    dicDanhSachChonNguyenLieu.Remove(idNguyenLieu);
                    lstDanhSachNguyenLieuXoa.Add(idNguyenLieu);

                    NguyenLieuInfo nguyenLieuInfo = null;
                    foreach (NguyenLieuInfo x in _danhsachnguyenlieu_thaydoi)
                    {
                        if (idNguyenLieu == x.MaNguyenLieu)
                        {
                            nguyenLieuInfo = x;
                            break;
                        }
                    }
                    if (nguyenLieuInfo != null)
                    {
                        _danhsachnguyenlieu_thaydoi.Remove(nguyenLieuInfo);
                    }
                    BingDingDataSource_dgvAllSource(_danhsachnguyenlieu_thaydoi);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Có lỗi xảy ra. Vui lòng kiểm tra lại! \n Thông tin lỗi:" + ex.Message, "Thông báo lỗi");
            }
        }

        // event thêm nguyên liệu mới cho nhà cung cấp.
        // INPUT:
        //     Lấy dữ liệu (id nguyên liệu, tên nguyên liệu) từ combox nguyên liệu (cbSource)
        //     Lấy dữ liệu đơn giá từ textbox (txtPrice)
        // Output:
        //     Đưa dữ liệu vào datagridview danh mục nguyên liệu (dgvAllSource)
        // Ngoài ra:
        //     1: Them thong tin nguyen lieu vao danh sach chon 
        //     2: Them thong tin nguyen lieu vao datagridview dgvAllSource.
        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                string idNguyenLieu = cbSource.SelectedValue.ToString();
                string thongTinNguyenLieu = cbSource.Text;
                double donGia = Convert.ToDouble(txtPrice.Text);
                if (dicDanhSachChonNguyenLieu.ContainsKey(idNguyenLieu))
                {
                    MessageBox.Show("Nguyên liệu đã được chọn. Vui lòng kiểm tra!", "Thông báo lỗi");
                    return;
                }
                NguyenLieuInfo nguyenLieuInfo = new NguyenLieuInfo()
                {
                    MaNguyenLieu = idNguyenLieu,
                    ThongTinNguyenLieu = thongTinNguyenLieu,
                    DonGia = donGia
                };

                //TODO:
                // 1: Them thong tin nguyen lieu vao danh sach chon 
                // 2: Them thong tin nguyen lieu vao datagridview dgvAllSource.
                dicDanhSachChonNguyenLieu.Add(idNguyenLieu, nguyenLieuInfo);
                _danhsachnguyenlieu_thaydoi.Add(nguyenLieuInfo);

                foreach (NguyenLieuInfo xx in _danhsachnguyenlieu_goc)
                {
                    if (idNguyenLieu == xx.MaNguyenLieu)
                    {
                        // nếu nguyên liệu thêm vào mà đã tồn tại trong _danhsachnguyenlieu_goc (danh sách nguyên liêu mà nhà cung cấp ban đầu)
                        // thì khi thêm nguyên liệu vào
                        // phải thực hiện loại bỏ nguyên liệu thêm vào khỏi danh sách đã xóa
                        lstDanhSachNguyenLieuXoa.Remove(idNguyenLieu);
                    }
                }

                dgvAllSource.Columns.Clear();
                dgvAllSource.DataSource = null;
                BingDingDataSource_dgvAllSource(_danhsachnguyenlieu_thaydoi);
            }
            catch (ArgumentException exFormat)
            {
                MessageBox.Show("Dữ liệu không hợp lệ. Vui lòng kiểm tra lại! \n Thông tin lỗi: " + exFormat.Message, "Thông báo lỗi");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Có lỗi xảy ra. Vui lòng kiểm tra lại! \n Thông tin lỗi:" + ex.Message, "Thông báo lỗi");
            }
        }
        #endregion

        #region Khai báo các biến
        // lưu trữ dữ liệu tên nhà cung cấp được lấy từ database trong datagridview dgvAllCompany của form frmManagerCompany
        private string _tennhacungcap_goc;
        // lưu trữ dữ liệu địa chỉ nhà cung cấp được lấy từ database trong datagridview dgvAllCompany của form frmManagerCompany
        private string _diachi_goc;
        // lưu trữ dữ liệu số điện tho nhà cung cấp được lấy từ database trong datagridview dgvAllCompany của form frmManagerCompany
        private string _phone_goc;
        List<NguyenLieuInfo> _danhsachnguyenlieu_goc = new List<NguyenLieuInfo>();
        List<NguyenLieuInfo> _danhsachnguyenlieu_thaydoi = new List<NguyenLieuInfo>();
        private Dictionary<string, NguyenLieuInfo> dicDanhSachChonNguyenLieu = new Dictionary<string, NguyenLieuInfo>();
        List<string> lstDanhSachNguyenLieuXoa = new List<string>();
        #endregion

        #region Phương thức & Inner Class
        // Class là một entity bao gồm các thuộc tính 
        // MaNguyenLieu, ThongTinNguyenLieu, DonGia
        // Các thuộc tính trên chính là tên Cột (columns) trong datagridview Danh Mục Nguyên Liệu (dgvAllSource)
        private class NguyenLieuInfo
        {
            public NguyenLieuInfo()
            {
            }

            public string MaNguyenLieu { get; set; }
            public string ThongTinNguyenLieu { get; set; }
            public double DonGia { get; set; }
        }

        // Đây là phương thức lấy dữ liệu từ (NguyenLieu, NhaCungCap)
        // Đưa dữ liệu tương ứng (MaNguyenLieu, ThongTinNguyenLieu, DonGia) vào gridview danh mục nguyên liệu (dgvAllSource)
        // Tạo dữ liệu (data) cho datasource của datagridview.
        // Hiển thị với dữ liệu (data) mới .
        private void BingDingDataSource_dgvAllSource(List<NguyenLieuInfo> data)
        {
            dgvAllSource.Columns.Clear();
            dgvAllSource.DataSource = null;
            dgvAllSource.DataSource = data;
            dgvAllSource.RowHeadersVisible = false;

            DataGridViewButtonColumn delete = new DataGridViewButtonColumn();
            delete.HeaderText = "";
            delete.Text = "Xóa";
            delete.Name = "btnDelete";
            delete.UseColumnTextForButtonValue = true;
            dgvAllSource.Columns.Add(delete);
        }

        // Đây là phương thức lấy dữ liệu từ entities (NguyenLieu, NhaCungCap)
        // Đưa dữ liệu tương ứng (MaNguyenLieu, ThongTinNguyenLieu, DonGia) vào gridview danh mục nguyên liệu (dgvAllSource)
        private void fillNguyenLieuInfo(string idNhaCungCap, List<string> listIdNguyenLieu)
        {
            try
            {
                Model1 db = new Model1();
                _danhsachnguyenlieu_goc = (from nguyenlieu in db.NguyenLieu
                                           join company in db.NhaCungCap on nguyenlieu.IdNguyenLieu equals company.IdNguyenLieu
                                           where company.IdNhaCungCap == idNhaCungCap
                                           //where listIdNguyenLieu.Contains(nguyenlieu.IdNguyenLieu)                              
                                           select new NguyenLieuInfo()
                                           {
                                               MaNguyenLieu = nguyenlieu.IdNguyenLieu,
                                               ThongTinNguyenLieu = nguyenlieu.TenNguyenLieu + " (" + nguyenlieu.DonViTinh + ")",
                                               DonGia = company.Gia
                                           }).ToList();

                // Luu giu danh sach nguyen lieu ban dau vao trong List _danhsachnguyenlieu_goc
                // Luu tru danh sach nguyen lieu vao trong list _danhsachnguyenlieu_thaydoi, dung de ghi nhan su thay doi
                // khi thuc  hien them, xoa nguyen lieu ra khoi danh sach nguyen lieu co trong datagridview.
                foreach (NguyenLieuInfo nl in _danhsachnguyenlieu_goc)
                {
                    _danhsachnguyenlieu_thaydoi.Add(nl);
                }
                foreach (NguyenLieuInfo nguyenlieuinfo in _danhsachnguyenlieu_goc)
                {
                    dicDanhSachChonNguyenLieu.Add(nguyenlieuinfo.MaNguyenLieu, nguyenlieuinfo);
                }
                BingDingDataSource_dgvAllSource(_danhsachnguyenlieu_thaydoi);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Có lỗi xảy ra. Vui lòng kiểm tra lại! \n Thông tin lỗi:" + ex.Message, "Thông báo lỗi");
            }
        }

        // Đây là phương thức lấy dữ liệu nhà cung cấp từ entity NhaCungCap
        // Đưa dữ liệu vào các control tương ứng (Mã nhà cung cấp, tên nhà cung cấp, địa chỉ, số điện thoại)
        private void ShowCompany(string idNhaCungCap)
        {
            try
            {
                txtIDCompany.Text = idNhaCungCap;
                // Không cho thay đổi mã nhà cung cấp vì Mã nhà cung cấp là khóa chính (PRIMARY KEY).            
                txtIDCompany.Enabled = false;
                txtPrice.Text = "";
                fillDataComboSource();

                Model1 db = new Model1();
                List<string> listIdNguyenLieu = new List<string>();
                bool fillCompanyDetail = false;
                foreach (NHACUNGCAP m in db.NhaCungCap)
                {
                    if (m.IdNhaCungCap == idNhaCungCap)
                    {
                        listIdNguyenLieu.Add(m.IdNguyenLieu);
                        if (!fillCompanyDetail)
                        {
                            _tennhacungcap_goc = m.TenNhaCungCap;
                            _diachi_goc = m.DiaChi;
                            _phone_goc = m.SoDienThoai;
                            fillCompanyDetail = true;
                        }
                    }
                }
                // Hiển thị thông tin nhà cung cấp trong các control textbox
                txtCompanyName.Text = _tennhacungcap_goc;
                txtAddress.Text = _diachi_goc;
                txtPhone.Text = _phone_goc;
                // Hiển thị thông tin nguyên liệu trong datagridview
                fillNguyenLieuInfo(idNhaCungCap, listIdNguyenLieu);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Có lỗi xảy ra. Vui lòng kiểm tra lại! \n Thông tin lỗi:" + ex.Message, "Thông báo lỗi");
            }
        }

        // Đây là phương thức lấy dữ liệu từ table NguyenLieu
        // Tạo key = IdNguyenLieu, value = TenNguyenLieu + " (" + DonViTinh + ")"
        // => đưa dữ liệu (key, value) vào control combox danh mục nguyên liệu (cbSource)
        private void fillDataComboSource()
        {
            try
            {
                Model1 db = new Model1();
                var SourceList = (from sources in db.NguyenLieu
                                  select new
                                  {
                                      MaNguyenLieu = sources.IdNguyenLieu,
                                      ThongTinNguyenLieu = sources.TenNguyenLieu + " (" + sources.DonViTinh + ")"
                                  }).ToList();


                cbSource.DataSource = SourceList;
                cbSource.ValueMember = "MaNguyenLieu";
                cbSource.DisplayMember = "ThongTinNguyenLieu";
                // Không cho người dùng nhập dữ liệu vào combox
                cbSource.DropDownStyle = ComboBoxStyle.DropDownList;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Có lỗi xảy ra. Vui lòng kiểm tra lại! \n Thông tin lỗi:" + ex.Message, "Thông báo lỗi");
            }
        }

        // Đây là phương thức dùng để đóng form frmCompanyInfo
        // Và hiển thị form frmManagerCompany
        private void BackFormManagerCompany()
        {
            this.Hide();
            frmManagerCompany mgManagerCompany = new frmManagerCompany(_idquanly);
            mgManagerCompany.ShowDialog();
        }

        private string XoaNguyenLieuNhaCungCap(Model1 db, string idnhacungcap)
        {
            string message = string.Empty;
            try
            {
                string message_delete = string.Empty;
                List<NHACUNGCAP> lstDanhSachNhaCungCapXoaNguyenLieu = new List<NHACUNGCAP>();
                int count = 1;
                foreach (string idNguyenLieu in lstDanhSachNguyenLieuXoa)
                {
                    foreach (NguyenLieuInfo nguyenlieu_bandau in _danhsachnguyenlieu_goc)
                    {
                        if (nguyenlieu_bandau.MaNguyenLieu == idNguyenLieu)
                        {
                            // Delete nguyen lieu
                            var company = new NHACUNGCAP
                            {
                                IdNhaCungCap = idnhacungcap,
                                IdNguyenLieu = idNguyenLieu,
                            };
                            db.NhaCungCap.Attach(company);
                            lstDanhSachNhaCungCapXoaNguyenLieu.Add(company);
                            message_delete += Environment.NewLine;
                            message_delete += "   " + count + ". nguyên liệu: " + nguyenlieu_bandau.ThongTinNguyenLieu;
                            break;
                        }
                    }
                }
                if (lstDanhSachNhaCungCapXoaNguyenLieu.Count > 0)
                {
                    db.NhaCungCap.RemoveRange(lstDanhSachNhaCungCapXoaNguyenLieu);
                    db.SaveChanges();
                    message += Environment.NewLine;
                    message += "  * Danh sách nguyên liệu đã xóa:";
                    message += message_delete;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Có lỗi xảy ra. Vui lòng kiểm tra lại! \n Thông tin lỗi:" + ex.Message, "Thông báo lỗi");
            }
            return message;
        }

        private string CapNhatDuLieuNhaCungCap(Model1 db, string idnhacungcap, string tennhacungcap, string sodienthoai, string diachi, bool thaydoithongtin_nhacungcap)
        {
            string message = string.Empty;
            try
            {
                List<NHACUNGCAP> lstThemNguyenLieuMoi = new List<NHACUNGCAP>();

                foreach (NguyenLieuInfo nguyenlieu_chinhsua in _danhsachnguyenlieu_thaydoi)
                {
                    bool themMoi = false;
                    foreach (NguyenLieuInfo nguyenlieu_bandau in _danhsachnguyenlieu_goc)
                    {
                        if (nguyenlieu_chinhsua.MaNguyenLieu == nguyenlieu_bandau.MaNguyenLieu)
                        {
                            // Kiểm tra đơn gia có thay đổi không?
                            // tên nhà cung cấp có thay đổi không?
                            // địa chỉ nhà cung cấp có thay đổi?
                            // số điện thoại nhà cung cấp có thay đổi?
                            if (nguyenlieu_chinhsua.DonGia != nguyenlieu_bandau.DonGia || thaydoithongtin_nhacungcap)
                            {
                                // cập nhật                           
                                var result = db.NhaCungCap.SingleOrDefault(b => b.IdNhaCungCap == idnhacungcap
                                    && b.IdNguyenLieu == nguyenlieu_chinhsua.MaNguyenLieu);
                                if (result != null)
                                {
                                    result.TenNhaCungCap = tennhacungcap;
                                    result.DiaChi = diachi;
                                    result.SoDienThoai = sodienthoai;
                                    result.Gia = nguyenlieu_chinhsua.DonGia;
                                    result.NgayDangKy = DateTime.Now;
                                    db.SaveChanges();
                                    message += Environment.NewLine;
                                    // Nếu mà không thay đổi đơn giá
                                    // Thì không hiển thị message cập nhật
                                    if (nguyenlieu_chinhsua.DonGia != nguyenlieu_bandau.DonGia)
                                    {
                                        message += "  - Cung cấp nguyên liệu (cập nhật): " + nguyenlieu_chinhsua.ThongTinNguyenLieu +
                                                          " đơn giá: " + nguyenlieu_chinhsua.DonGia;
                                    }
                                }
                            }
                            // không thay đổi thì bỏ qua không cập nhật.
                            themMoi = false;
                            break;
                        }
                        themMoi = true;
                    }
                    if (themMoi)
                    {
                        // Insert nguyên liệu mới vào
                        var company = new NHACUNGCAP
                        {
                            IdNhaCungCap = idnhacungcap,
                            TenNhaCungCap = tennhacungcap,
                            DiaChi = diachi,
                            SoDienThoai = sodienthoai,
                            IdNguyenLieu = nguyenlieu_chinhsua.MaNguyenLieu,
                            Gia = nguyenlieu_chinhsua.DonGia,
                            NgayDangKy = DateTime.Now
                        };
                        lstThemNguyenLieuMoi.Add(company);
                        message += Environment.NewLine;
                        message += "  - Cung cấp nguyên liệu (thêm mới): " + nguyenlieu_chinhsua.ThongTinNguyenLieu +
                                          " đơn giá: " + nguyenlieu_chinhsua.DonGia;
                    }
                }
                // Kiem tra neu co nguyen lieu moi 
                if (lstThemNguyenLieuMoi.Count > 0)
                {
                    db.NhaCungCap.AddRange(lstThemNguyenLieuMoi);
                    db.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Có lỗi xảy ra. Vui lòng kiểm tra lại! \n Thông tin lỗi:" + ex.Message, "Thông báo lỗi");
            }
            return message;
        }
        #endregion
    }
}
