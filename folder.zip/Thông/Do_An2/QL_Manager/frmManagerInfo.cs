﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Do_An2
{
    public partial class frmManagerInfo : Form
    {
        private int _IdUser;
        private int _IdManager;
        private DateTime _Starter;
        private string _Name;
        private string _CMND;
        private string _Address;
        private DateTime _Birthday;
        private string _Phone;
        private bool _Gender;
        public frmManagerInfo(int IDManager)
        {
            InitializeComponent();
            ShowInfoManager(IDManager);
        }

        private void ShowInfoManager(int IDManager)
        {
            try
            {
                Model1 db = new Model1();
                foreach (Managers m in db.Manager)
                {
                    if (m.idManager == IDManager)
                    {
                        _IdUser = m.idTaiKhoan;
                        _IdManager = m.idManager;
                        _Starter = (DateTime)m.Ngay_Vo_Lam;
                        _Name = m.Name;
                        _CMND = m.CMND;
                        _Address = m.Dia_Chi;
                        _Birthday = (DateTime)m.Ngay_Sinh;
                        _Phone = m.SDT;
                        _Gender = (bool)m.Gioi_Tinh;
                    }
                    FillFormManagerInfo();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Có lỗi xảy ra. Vui lòng kiểm tra lại! \n Thông tin lỗi:" + ex.Message, "Thông báo lỗi");
            }
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            FillFormManagerInfo();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            string tenquanly = txtName.Text.Trim();
            string ngaysinh = txtBirthday.Text.Trim();
            string diachi = txtAddress.Text.Trim();
            string cmnd = txtCMND.Text.Trim();
            if (tenquanly == string.Empty)
            {
                // hiển thị thông báo lỗi và dừng thực hiện lưu
                MessageBox.Show("Vui lòng nhập tên quản lý!", "Thông báo lỗi");
                return;
            }
            try
            {
                Model1 db = new Model1();
                MessageBox.Show("Vui lòng nhập tên quản lý!" + _IdManager, "Thông báo lỗi");
                var result = db.Manager.SingleOrDefault(b => b.idManager == _IdManager);
                if (result != null)
                {
                    result.Name = tenquanly;
                    result.Ngay_Sinh = Convert.ToDateTime(ngaysinh);
                    result.SDT = txtPhone.Text;
                    result.Dia_Chi = diachi;
                    result.CMND = cmnd;
                    result.Gioi_Tinh = rdMale.Checked;
                    // vì quá trình lưu diễn ra mất một khoản thời gian
                    // nên trong quá trình xử lý thì vô hiệu hóa các button chức năng
                    btnBack.Enabled = false;
                    btnSave.Enabled = false;
                    btnReset.Enabled = false;
                    db.SaveChanges();
                    MessageBox.Show("Đã cập nhật thành công", "Thông báo!");
                }
                else
                {
                    MessageBox.Show("Không tìm thấy thông tin quản lý", "Thông báo lỗi!");
                }
            }
            catch (FormatException exFormat)
            {
                MessageBox.Show("Dữ liệu không hợp lệ. Vui lòng kiểm tra lại! \n Thông tin lỗi: " + exFormat.Message, "Thông báo lỗi");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Có lỗi xảy ra. Vui lòng kiểm tra lại! \n Thông tin lỗi:" + ex.Message, "Thông báo lỗi");
            }
            finally
            {
                btnBack.Enabled = true;
                btnSave.Enabled = true;
                btnReset.Enabled = true;
            }

        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Hide();
            frmManager mg = new frmManager(_IdManager);
            mg.ShowDialog();
        }

        #region [Khai báo các method]
        private void FillFormManagerInfo()
        {
            // Thong tin tai khoan
            lbUser.Text = _IdUser.ToString();
            lbIDManager.Text = _IdManager.ToString();
            lbStarter.Text = _Starter.ToString();
            // Thong tin ca nhan
            txtName.Text = _Name;
            txtCMND.Text = _CMND;
            txtAddress.Text = _Address;
            txtBirthday.Text = _Birthday.ToString();
            txtPhone.Text = _Phone;
            rdFemale.Checked = true;
            if (_Gender)
            {
                rdMale.Checked = true;
            }
        }

        #endregion       
    }
}
