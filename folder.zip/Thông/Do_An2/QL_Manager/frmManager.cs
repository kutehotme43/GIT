﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Entity;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Do_An2
{
    public partial class frmManager : Form
    {
        #region khai báo biến
        private int IDManager;
        private bool addButtonForDGVOrder = false;
        #endregion
        public frmManager(int idManager)
        {
            InitializeComponent();
            lbCurrentTime.Text = "Bây giờ: " + DateTime.Now.ToString();            
            // Khi đăng nhâp xong
            // Thì form đăng nhập phải thiết lập giá trị cho biến IDManager
            // Tạm thời gán bằng 1 (đây là IdManager đã có trong table Manager)
            IDManager = idManager;
            getNameManager();
            getDataOrder();
        }

        #region khai báo phương thức
        private void getDataOrder()
        {
            try
            {
                Model1 db = new Model1();
                var OrderList = (from order in db.DonDatHang
                                 join manager in db.Manager on order.idManager equals manager.idManager
                                 orderby order.NgayDatHang descending, order.IdDonDatNguyenLieu descending
                                 select new
                                 {
                                     MaDon = order.IdDonDatNguyenLieu,
                                     QuanLy = manager.Name,
                                     TinhTrang = order.TrangThai ? "đã nhận" : "chưa nhận",
                                     NgayDat = order.NgayDatHang + " (ngày)",
                                     ThoiHanNhan = order.ThoiHan
                                 }).Distinct().ToList();
                dgvOrder.DataSource = OrderList;
                if (!addButtonForDGVOrder)
                {
                    DataGridViewButtonColumn chitiet = new DataGridViewButtonColumn();
                    chitiet.HeaderText = "";
                    chitiet.Text = "Chi tiết";
                    chitiet.Name = "btnDetail";
                    chitiet.UseColumnTextForButtonValue = true;
                    dgvOrder.Columns.Add(chitiet);
                    addButtonForDGVOrder = true;
                }
                dgvOrder.Refresh();
                dgvOrder.RowHeadersVisible = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Có lỗi xảy ra. Vui lòng kiểm tra lại! \n Thông tin lỗi:" + ex.Message, "Thông báo lỗi");
            }
        }

        private void getNameManager()
        {
            try
            {
                Model1 db = new Model1();
                foreach (Managers m in db.Manager)
                {
                    if (m.idManager == IDManager)
                    {
                        lbTenQuanLy.Text = m.Name;
                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Có lỗi xảy ra. Vui lòng kiểm tra lại! \n Thông tin lỗi:" + ex.Message, "Thông báo lỗi");
            }
        }

        #endregion

        #region event control

        private void lnkDangXuat_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            //MessageBox.Show("Đăng Xuất");
            this.Hide();
            Form1 frmDangNhap = new Form1();
            frmDangNhap.ShowDialog();

        }
        private void lnkShowInfoManager_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            frmManagerInfo mg = new frmManagerInfo(IDManager);
            mg.ShowDialog();

        }

        private void lnkCompany_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            frmManagerCompany mgCompany = new frmManagerCompany(IDManager);
            mgCompany.ShowDialog();
        }

        private void lnkSource_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            frmNguyenLieu mgNguyenLieu = new frmNguyenLieu(IDManager);
            mgNguyenLieu.ShowDialog();
        }


        private void rdNoReceived_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                Model1 db = new Model1();
                var OrderList = (from order in db.DonDatHang
                                 join manager in db.Manager on order.idManager equals manager.idManager
                                 join company in db.NhaCungCap on order.IdNhaCungCap equals company.IdNhaCungCap
                                 join source in db.NguyenLieu on order.IdNguyenLieu equals source.IdNguyenLieu
                                 where order.IdNguyenLieu == company.IdNguyenLieu & !order.TrangThai
                                 select new
                                 {
                                     MaDon = order.IdDonDatNguyenLieu,
                                     QuanLy = manager.Name,
                                     TinhTrang = order.TrangThai ? "đã nhận" : "chưa nhận",
                                     NgayDat = order.NgayDatHang + " (ngày)",
                                     ThoiHanNhan = order.ThoiHan
                                 }).Distinct().ToList();
                dgvOrder.DataSource = OrderList;
                dgvOrder.Refresh();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Có lỗi xảy ra. Vui lòng kiểm tra lại! \n Thông tin lỗi:" + ex.Message, "Thông báo lỗi");
            }
        }

        private void rdAllOrder_CheckedChanged(object sender, EventArgs e)
        {
            getDataOrder();
        }

        private void rdReceived_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                Model1 db = new Model1();
                var OrderList = (from order in db.DonDatHang
                                 join manager in db.Manager on order.idManager equals manager.idManager
                                 join company in db.NhaCungCap on order.IdNhaCungCap equals company.IdNhaCungCap
                                 join source in db.NguyenLieu on order.IdNguyenLieu equals source.IdNguyenLieu
                                 where order.IdNguyenLieu == company.IdNguyenLieu & order.TrangThai
                                 select new
                                 {
                                     MaDon = order.IdDonDatNguyenLieu,
                                     QuanLy = manager.Name,
                                     TinhTrang = order.TrangThai ? "đã nhận" : "chưa nhận",
                                     NgayDat = order.NgayDatHang + " (ngày)",
                                     ThoiHanNhan = order.ThoiHan
                                 }).Distinct().ToList();
                dgvOrder.DataSource = OrderList;
                dgvOrder.Refresh();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Có lỗi xảy ra. Vui lòng kiểm tra lại! \n Thông tin lỗi:" + ex.Message, "Thông báo lỗi");
            }
        }

        private void rdOutOfDate_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                DateTime today = DateTime.Now;
                Model1 db = new Model1();
                var OrderList = (from order in db.DonDatHang
                                 join manager in db.Manager on order.idManager equals manager.idManager
                                 join company in db.NhaCungCap on order.IdNhaCungCap equals company.IdNhaCungCap
                                 join source in db.NguyenLieu on order.IdNguyenLieu equals source.IdNguyenLieu
                                 where order.IdNguyenLieu == company.IdNguyenLieu
                                 & DbFunctions.AddDays(today, -order.ThoiHan) > order.NgayDatHang
                                 & !order.TrangThai

                                 select new
                                 {
                                     MaDon = order.IdDonDatNguyenLieu,
                                     QuanLy = manager.Name,
                                     TinhTrang = order.TrangThai ? "đã nhận" : "chưa nhận",
                                     NgayDat = order.NgayDatHang + " (ngày)",
                                     ThoiHanNhan = order.ThoiHan
                                 }).Distinct().ToList();
                dgvOrder.DataSource = OrderList;
                dgvOrder.RowHeadersVisible = false;
                dgvOrder.Refresh();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Có lỗi xảy ra. Vui lòng kiểm tra lại! \n Thông tin lỗi:" + ex.Message, "Thông báo lỗi");
            }
        }


        private void lnkResource_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            frmManagerOrder mgOrder = new frmManagerOrder(IDManager);
            mgOrder.ShowDialog();
        }

        private void dgvOrder_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                var senderGrid = (DataGridView)sender;
                if (senderGrid.Columns[e.ColumnIndex] is DataGridViewButtonColumn && e.RowIndex >= 0)
                {
                    string madonhang = dgvOrder.Rows[e.RowIndex].Cells["MaDon"].Value.ToString();
                    // Gọi form hiển thị chi tiết đơn hàng
                    this.Hide();
                    frmOrderDetail mgOrderDetail = new frmOrderDetail(IDManager, madonhang);
                    mgOrderDetail.ShowDialog();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Có lỗi xảy ra. Vui lòng kiểm tra lại! \n Thông tin lỗi:" + ex.Message, "Thông báo lỗi");
            }
        }

        #endregion

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

            this.Dispose();
            this.Close();
        }

        private void frmManager_Load(object sender, EventArgs e)
        {

        }
    }


}
